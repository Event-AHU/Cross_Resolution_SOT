import wandb
runid = wandb.util.generate_id()        # runid就是run_path的后缀
# print('继续训练...')
# runid = '3230jq2r'
resume =  'allow'
