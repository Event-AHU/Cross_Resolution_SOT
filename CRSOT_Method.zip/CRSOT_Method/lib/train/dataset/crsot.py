import torch
import os
import os.path
import numpy as np
import pandas
import random
from collections import OrderedDict
from lib.train.data import jpeg4py_loader,jpeg4py_loader_w_failsafe
from .base_video_dataset import BaseVideoDataset
from lib.train.admin import env_settings
import pdb
import cv2 as cv
class CRSOT(BaseVideoDataset):
    def __init__(self, root=None, image_loader=jpeg4py_loader_w_failsafe, data_fraction=None):
        self.root = root
        super().__init__('CRSOT', root, image_loader)

        # video_name for each sequence
        self.sequence_list = os.listdir(self.root)

        if data_fraction is not None:
            self.sequence_list = random.sample(self.sequence_list, int(len(self.sequence_list) * data_fraction))
        
    def get_name(self):
        return 'crsot'
    def get_num_sequences(self):
        return len(self.sequence_list)
    def _read_bb_anno(self, seq_path):
        bb_anno_file = os.path.join(seq_path, 'groundtruth.txt')
        gt = pandas.read_csv(bb_anno_file, delimiter=',', header=None, dtype=np.float32, na_filter=False,
                             low_memory=False).values
        return torch.tensor(gt)

    def get_sequence_info(self, seq_id):
        seq_name = self.sequence_list[seq_id]
        seq_path = os.path.join(self.root, seq_name)
        bbox = self._read_bb_anno(seq_path)

        valid = (bbox[:, 2] > 0) & (bbox[:, 3] > 0)
        visible = valid.clone().byte()
        #print("bbox",len(visible))        
        return {'bbox': bbox, 'valid': valid, 'visible': visible}

    def _get_frame(self, seq_path, frame_id):    
        #try:
        frame_path_v = os.path.join(seq_path, 'rgb_imgs', sorted([p for p in os.listdir(os.path.join(seq_path, 'rgb_imgs')) if os.path.splitext(p)[1] in ['.png','.jpg','.bmp']])[frame_id])
        frame_path_e = os.path.join(seq_path, 'event_imgs', sorted([p for p in os.listdir(os.path.join(seq_path, 'event_imgs')) if os.path.splitext(p)[1] in ['.jpg','.png','.bmp']])[frame_id])
        # except(IndexError)        
        # except(IndexError):
            # print("seq_path",seq_path) 
        #pdb.set_trace()
        im = cv.imread(frame_path_v, cv.IMREAD_COLOR)
        
        # convert to rgb and return
        frame_path_v=cv.cvtColor(im, cv.COLOR_BGR2RGB)
        #print("frame_path**********************************",frame_path_v.shape)        
        frame_path_v=self.image_loader(frame_path_v)
        #print("111111111111",frame_path_v.shape)
        w,h=frame_path_v.shape[0],frame_path_v.shape[1]
        frame_path_e=self.image_loader(frame_path_e,w,h) 
        #print("frame_path---------------------",frame_path_v.shape,frame_path_e.shape)
        #pdb.set_trace()
        return frame_path_v,frame_path_e
        
    # def _get_frame_e(self, seq_path, frame_id,w,h):
        # #print(os.listdir(os.path.join(seq_path, 'event_imgs')))
        # #try:
        # frame_path_e = os.path.join(seq_path, 'event_imgs', sorted([p for p in os.listdir(os.path.join(seq_path, 'event_imgs')) if os.path.splitext(p)[1] in ['.jpg','.png','.bmp']])[frame_id])
        # # except(IndexError):
            # # print("seq_path",seq_path)        
        # return self.image_loader_e(frame_path_e,w,h)

    def get_frames(self, seq_id, frame_ids, anno=None):
        #print(self.sequence_list,self.sequence_list[seq_id])
        #print("111111111111111111111111111111111111111111111111111111111111111111111111111111111111111")
        seq_name = self.sequence_list[seq_id]
        seq_path = os.path.join(self.root, seq_name)
        frame_list_v=[]
        frame_list_e=[]
        for f in frame_ids:
            frame_path_v = os.path.join(seq_path, 'rgb_imgs', sorted([p for p in os.listdir(os.path.join(seq_path, 'rgb_imgs')) if os.path.splitext(p)[1] in ['.png','.jpg','.bmp']])[f])
            frame_path_e = os.path.join(seq_path, 'event_imgs', sorted([p for p in os.listdir(os.path.join(seq_path, 'event_imgs')) if os.path.splitext(p)[1] in ['.jpg','.png','.bmp']])[f])
            im = cv.imread(frame_path_v, cv.IMREAD_COLOR)        
            # convert to rgb and return
            frame_v=cv.cvtColor(im, cv.COLOR_BGR2RGB)
            w, h = frame_v.shape[0],frame_v.shape[1]            
            try:
                im = cv.imread(frame_path_e, cv.IMREAD_COLOR)
                frame_e=cv.cvtColor(im, cv.COLOR_BGR2RGB)
                if im.shape[0]!=w or im.shape[1]!=h:
                   frame_e=cv.resize(frame_e,(h,w))
            except:
                print('ERROR: Could not read image "{}"'.format(frame_path_e))          
            
            
            
            #print("111111111111",frame_path_v.shape)
            #frame_path_v,frame_path_e=self._get_frame(seq_path, f)
            #print(type(frame_path_v),frame_path_v.shape,frame_path_e.shape)
            frame_list_v.append(frame_v)
            frame_list_e.append(frame_e)
        #print("image_loader",image_loader)    
        #print(frame_list_v[0].shape,frame_list_e[0].shape,len(frame_list_v),len(frame_list_e))
        #frame_list_e = [self._get_frame_e(seq_path, f) for f in frame_ids]
        frame_list  = frame_list_v + frame_list_e # 6
        #print('get_frames frame_list', len(frame_list))
        if anno is None:
            anno = self.get_sequence_info(seq_path)

        anno_frames = {}
        for key, value in anno.items():
            anno_frames[key] = [value[f_id, ...].clone() for f_id in frame_ids]

        object_meta = OrderedDict({'object_class_name': None,
                                   'motion_class': None,
                                   'major_class': None,
                                   'root_class': None,
                                   'motion_adverb': None})

        #return frame_list_v, frame_list_i, anno_frames, object_meta
        return frame_list, anno_frames, object_meta
