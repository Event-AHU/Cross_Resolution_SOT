import torch
import os
import os.path
import numpy as np
import pandas
import random
from collections import OrderedDict
import cv2 as cv
from lib.train.data import jpeg4py_loader,jpeg4py_loader_w_failsafe
from .base_video_dataset import BaseVideoDataset
from lib.train.admin import env_settings
import pdb
class VISEVENT_TEST(BaseVideoDataset):
    def __init__(self, root=None, image_loader=jpeg4py_loader_w_failsafe, data_fraction=None):
        self.root = env_settings().visevent_dir if root is None else root
        super().__init__('VISEVENT_TEST', root, image_loader)

        # video_name for each sequence
        #self.sequence_list = os.listdir(self.root)
        self.sequence_list =['video_0073', 'basketball_0076', '00511_person_outdoor6', 'dvSave-2021_02_14_16_56_18_car2', '00432_UAV_outdoor6', 'video_0004', 'video_0049', '00490_UAV_outdoor6', 'dvSave-2021_02_15_10_23_05_boyhead', 'dvSave-2021_02_06_15_18_36_redcar', '00503_UAV_outdoor6', 'dvSave-2021_02_15_10_26_11_chicken', 'dvSave-2021_02_06_09_13_36_person2', '00471_UAV_outdoor6', 'dvSave-2021_02_08_21_04_56_car6', 'dvSave-2021_02_06_09_14_18_whitecar1', 'traffic_0070', 'dvSave-2021_02_14_16_56_01_house', 'dvSave-2021_02_14_16_48_45_car3', '00425_UAV_outdoor6', 'dvSave-2021_02_06_17_34_58_personBasketball', '00340_UAV_outdoor6', 'dvSave-2021_02_04_21_04_05', 'dvSave-2021_02_06_17_57_54_personFootball', 'dvSave-2021_02_14_16_55_35_person1', 'dvSave-2021_02_14_16_31_07_whitecar1', '00325_UAV_outdoor5', '00147_tank_outdoor2', '00297_tennis_outdoor4', 'dvSave-2021_02_12_13_38_26', 'dvSave-2021_02_06_08_56_40_windowPattern2', 'dvSave-2021_02_08_21_02_13_motor2', 'dvSave-2021_02_06_15_12_44_car', 'dightNUM_001', '00355_UAV_outdoor6', 'dvSave-2021_02_14_16_30_20_car2', 'dvSave-2021_02_06_09_24_39_oldman1', 'dvSave-2021_02_15_13_24_03_girlhead', 'dvSave-2021_02_14_16_42_14_car1', '00445_UAV_outdoor6', 'dvSave-2021_02_06_17_53_39_personFootball', 'dvSave-2021_02_06_17_49_51_personBasketball', 'dvSave-2021_02_14_16_26_44_girl', 'dvSave-2021_02_15_23_54_17', 'dvSave-2021_02_15_13_02_21_Chicken', 'dvSave-2021_02_15_13_09_09_person', 'video_0067', 'dvSave-2021_02_15_13_05_43_Chicken', '00413_UAV_outdoor6', '00408_UAV_outdoor6', 'dvSave-2021_02_15_13_13_44_whitecar', 'dvSave-2021_02_08_21_17_43_car5', 'dvSave-2021_02_06_17_20_28_personFootball', 'tennis_long_007', 'dvSave-2021_02_16_17_15_53', 'dvSave-2021_02_08_21_07_02_car2', 'traffic_0061', 'dvSave-2021_02_14_16_34_48_person1', 'dvSave-2021_02_06_09_17_11_person', 'traffic_0049', '00510_person_outdoor6', 'dvSave-2021_02_06_10_11_59_paperClips', 'dvSave-2021_02_14_16_45_13_car7', '00449_UAV_outdoor6', 'video_0018', '00483_UAV_outdoor6', 'dvSave-2021_02_06_10_14_17_paperClip', 'dvSave-2021_02_15_12_45_02_Duck', 'dvSave-2021_02_06_17_15_20_whitecar', 'traffic_0037', 'traffic_0040', 'dvSave-2021_02_06_15_14_26_blackcar', 'dvSave-2021_02_14_16_43_54_car4', 'dvSave-2021_02_16_17_23_10', '00435_UAV_outdoor6', '00451_UAV_outdoor6', 'dvSave-2021_02_15_10_26_52_basketball2', 'dvSave-2021_02_14_16_37_15_person', 'dvSave-2021_02_15_13_14_18_blackcar', '00437_UAV_outdoor6', 'dvSave-2021_02_08_21_15_49_car8', 'dvSave-2021_02_14_16_31_07_blackcar2', 'dvSave-2021_02_06_09_58_27_DigitAI', 'video_0029', '00455_UAV_outdoor6', 'dvSave-2021_02_08_21_06_03_car3', 'dvSave-2021_02_08_21_06_03_motor2', 'dvSave-2021_02_16_17_07_38', 'dvSave-2021_02_04_20_41_53', 'dvSave-2021_02_06_09_16_35_car', 'dvSave-2021_02_15_13_10_54_person', 'dvSave-2021_02_14_16_31_07_person1', '00453_UAV_outdoor6', 'dvSave-2021_02_14_16_40_59_blackcar1', 'dvSave-2021_02_06_09_10_52_car3', 'dvSave-2021_02_06_09_11_41_person4', 'dvSave-2021_02_08_21_06_03_car7', 'dvSave-2021_02_14_16_56_18_car4', 'dvSave-2021_02_14_16_29_49_car2', 'dvSave-2021_02_14_16_34_48_car2', 'dvSave-2021_02_14_16_40_59_motor1', 'traffic_0028', 'dvSave-2021_02_08_21_15_49_car3', '00406_UAV_outdoor6', 'dvSave-2021_02_14_16_26_44_person1', '00197_driving_outdoor3', 'dvSave-2021_02_04_20_56_55', '00423_UAV_outdoor6', 'traffic_0006', 'dvSave-2021_02_06_17_31_03_personBasketball', 'dvSave-2021_02_06_18_04_18_person1', 'dvSave-2021_02_15_10_26_52_personHead1', 'video_0076', 'dvSave-2021_02_06_09_11_41_person1', 'dvSave-2021_02_15_10_14_18_chicken', 'dvSave-2021_02_08_21_02_13_car3', 'dvSave-2021_02_15_13_08_12_blackcar', '00421_UAV_outdoor6', 'dvSave-2021_02_14_16_28_37_car3', 'dvSave-2021_02_14_16_43_23_car3', 'traffic_0067', 'dvSave-2021_02_12_13_39_56', 'dvSave-2021_02_15_10_26_52_basketball1', 'dvSave-2021_02_06_09_33_23_person1', 'dvSave-2021_02_06_09_35_08_Pedestrian', 'traffic_0052', 'video_0054', '00473_UAV_outdoor6', 'dvSave-2021_02_14_16_51_21_car1', 'dvSave-2021_02_15_23_56_17', '00506_person_outdoor6', '00292_tennis_outdoor4', '00236_tennis_outdoor4', 'dvSave-2021_02_06_15_17_48_whitecar', 'dvSave-2021_02_14_16_45_13_car5', 'dvSave-2021_02_06_15_16_07_car', 'dvSave-2021_02_14_16_56_59_car2', 'dvSave-2021_02_06_09_16_06_person', 'video_0079', 'dvSave-2021_02_06_09_09_44_person6', 'dvSave-2021_02_06_09_09_44_person3', 'video_0064', 'dvSave-2021_02_06_10_17_16_paperClips', 'dvSave-2021_02_15_12_44_27_chicken', 'dvSave-2021_02_06_09_10_52_car2', 'dvSave-2021_02_14_16_46_34_car8', 'dvSave-2021_02_08_21_04_56_car3', 'dvSave-2021_02_14_16_51_21_motor1', 'video_0060', '00430_UAV_outdoor6', 'dvSave-2021_02_14_16_46_34_car3', 'UAV_long_001', 'dvSave-2021_02_08_21_17_43_car3', 'dvSave-2021_02_14_16_37_15_car5', '00398_UAV_outdoor6', 'video_0005', 'dvSave-2021_02_16_17_38_25', 'traffic_0058', 'dvSave-2021_02_15_10_23_05_basketall', '00464_UAV_outdoor6', 'dvSave-2021_02_14_16_28_37_person1', 'dvSave-2021_02_14_16_56_18_car6', '00514_person_outdoor6', '00458_UAV_outdoor6', 'tennis_long_004', 'dvSave-2021_02_06_08_56_18_windowPattern', 'dvSave-2021_02_06_08_58_43_cat', 'traffic_0064', 'dvSave-2021_02_08_21_15_49_car1', 'dvSave-2021_02_06_09_24_26_Pedestrian1', 'video_0050', 'dvSave-2021_02_06_17_51_05_personBasketball', '00374_UAV_outdoor6', 'dvSave-2021_02_15_10_24_03_basketball', '00370_UAV_outdoor6', '00335_UAV_outdoor5', 'dvSave-2021_02_15_12_56_56_Fish', 'dvSave-2021_02_06_09_33_23_person5', 'dvSave-2021_02_16_17_29_37', 'dvSave-2021_02_06_09_36_15_Pedestrian', 'dvSave-2021_02_14_16_45_13_car1', 'dvSave-2021_02_06_17_23_26_personFootball', 'basketball_0078', '00442_UAV_outdoor6', 'dvSave-2021_02_14_16_26_44_car3', 'dvSave-2021_02_06_17_47_49_personBasketball', 'dydrant_001', 'traffic_0013', 'dvSave-2021_02_14_16_34_11_person1', 'dvSave-2021_02_06_09_09_44_blackcar', 'dvSave-2021_02_16_17_42_50', 'dvSave-2021_02_06_17_16_26_whitecar', 'video_0008', 'dvSave-2021_02_14_16_28_37_car2', 'dvSave-2021_02_14_16_56_59_car4', 'traffic_0073', 'dvSave-2021_02_16_17_20_20', 'traffic_0023', '00314_UAV_outdoor5', 'dvSave-2021_02_08_21_07_52', 'dvSave-2021_02_06_09_22_41_person1', 'tennis_long_005', 'dvSave-2021_02_06_10_09_04_bottle', 'dvSave-2021_02_06_09_09_44_person7', '00439_UAV_outdoor6', 'dvSave-2021_02_14_16_46_34_car16', '00447_UAV_outdoor6', 'tennis_long_001', 'dvSave-2021_02_14_16_35_40_car2', 'video_0056', 'dvSave-2021_02_14_16_31_07_redtaxi01', '00419_UAV_outdoor6', 'dvSave-2021_02_12_13_46_18', 'video_0058', 'dvSave-2021_02_15_13_25_36_girlhead', '00462_UAV_outdoor6', 'dvSave-2021_02_06_09_21_53_car', 'dvSave-2021_02_15_10_24_03_boyhead', 'video_0015', 'dvSave-2021_02_14_16_37_15_motor2', '00433_UAV_outdoor6', 'dvSave-2021_02_14_16_56_59_car6', '00241_tennis_outdoor4', 'dvSave-2021_02_08_21_05_56_motor', 'dvSave-2021_02_15_13_24_49_girlhead', 'dvSave-2021_02_04_21_20_22', 'dvSave-2021_02_04_20_49_43', 'dvSave-2021_02_14_16_46_34_car10', 'dvSave-2021_02_06_17_21_41_personFootball', 'video_0070', 'dvSave-2021_02_15_12_53_54_personHead', 'dvSave-2021_02_06_09_14_18_girl1', 'traffic_0034', 'dvSave-2021_02_04_21_18_52', 'dvSave-2021_02_14_16_34_11_car3', '00141_tank_outdoor2', 'video_0009', 'dvSave-2021_02_15_13_12_45_redcar', '00466_UAV_outdoor6', 'dvSave-2021_02_15_12_58_56_person', 'dvSave-2021_02_06_10_05_38_phone', 'dvSave-2021_02_06_09_14_18_person5', 'dvSave-2021_02_16_17_12_18', 'video_0041', 'dvSave-2021_02_14_16_48_45_car5', 'video_0026', 'dvSave-2021_02_14_16_37_15_car2', '00345_UAV_outdoor6', 'dvSave-2021_02_15_10_12_19_basketball', 'dvSave-2021_02_15_13_04_57_Duck', 'dvSave-2021_02_06_08_52_19_rotateball', 'dvSave-2021_02_14_16_43_54_car2', 'dvSave-2021_02_06_17_33_01_personBasketball', 'dvSave-2021_02_14_16_48_45_car8', 'dvSave-2021_02_08_21_06_03_car5', 'dvSave-2021_02_06_18_04_18_person3', 'video_0045', 'dvSave-2021_02_15_13_28_20_cash', '00351_UAV_outdoor6', '00404_UAV_outdoor6', 'dvSave-2021_02_15_12_58_05_personHead2', 'traffic_0019', 'dvSave-2021_02_14_16_40_59_car1', 'dvSave-2021_02_06_15_15_36_redcar', 'traffic_0043', 'dvSave-2021_02_14_17_00_48', 'dvSave-2021_02_06_09_23_50_person1', '00428_UAV_outdoor6', 'roadLight_001', 'dvSave-2021_02_06_17_27_53_personFootball', '00331_UAV_outdoor5', 'video_0021', 'dvSave-2021_02_14_16_43_23_car4', 'dvSave-2021_02_15_13_27_20_bottle', 'dvSave-2021_02_06_08_57_35_machineBrad', 'dvSave-2021_02_06_10_03_17_GreenPlant', 'dvSave-2021_02_06_09_13_36_person0', '00385_UAV_outdoor6', 'dvSave-2021_02_14_16_31_07_whitecar4', 'dvSave-2021_02_06_15_08_41_flag', 'dvSave-2021_02_15_10_22_23_basketball', 'dvSave-2021_02_12_13_43_54', 'dvSave-2021_02_06_09_10_52_car1', 'dvSave-2021_02_14_16_42_44_car6', 'traffic_0055', 'dvSave-2021_02_12_13_56_29', 'dvSave-2021_02_14_16_42_44_car3', 'dvSave-2021_02_06_17_41_45_personBasketball', 'tennis_long_003', 'dvSave-2021_02_14_16_22_06', 'dvSave-2021_02_14_16_46_34_car5', '00282_tennis_outdoor4', 'dvSave-2021_02_14_16_53_15_flag', 'dvSave-2021_02_14_16_30_05_car1', 'dvSave-2021_02_12_13_51_43', 'traffic_0046', 'dvSave-2021_02_14_17_02_37_roadflag', '00416_UAV_outdoor6', 'video_0032', 'dvSave-2021_02_15_12_56_56_personHead', 'dvSave-2021_02_06_09_11_41_car1', 'dvSave-2021_02_14_16_21_40', 'dvSave-2021_02_06_09_36_44_Pedestrian', 'tennis_long_002', '00478_UAV_outdoor6', 'tennis_long_006', 'dvSave-2021_02_15_10_22_23_boyhead', 'dvSave-2021_02_14_16_46_34_car12', '00410_UAV_outdoor6', 'dvSave-2021_02_14_16_40_59_car7', 'video_0039', 'dvSave-2021_02_15_13_01_16_Duck', 'dvSave-2021_02_15_23_51_36', 'dvSave-2021_02_04_21_21_24', 'dvSave-2021_02_14_16_40_59_car4', 'dvSave-2021_02_06_17_36_49_personBasketball', 'dvSave-2021_02_16_17_34_11', 'dvSave-2021_02_06_17_45_17_personBasketball', '00508_person_outdoor6', 'dvSave-2021_02_06_08_33_09_cat']
        if data_fraction is not None:
            self.sequence_list = random.sample(self.sequence_list, int(len(self.sequence_list) * data_fraction))
        
    def get_name(self):
        return 'visevent_test'
    def get_num_sequences(self):
        return len(self.sequence_list)
    def _read_bb_anno(self, seq_path):
        bb_anno_file = os.path.join(seq_path, 'groundtruth.txt')
        gt = pandas.read_csv(bb_anno_file, delimiter=',', header=None, dtype=np.float32, na_filter=False,
                             low_memory=False).values
        return torch.tensor(gt)

    def get_sequence_info(self, seq_id):
        seq_name = self.sequence_list[seq_id]
        seq_path = os.path.join(self.root, seq_name)
        bbox = self._read_bb_anno(seq_path)

        valid = (bbox[:, 2] > 0) & (bbox[:, 3] > 0)
        visible = valid.clone().byte()
        #print("bbox",len(visible))        
        return {'bbox': bbox, 'valid': valid, 'visible': visible}

    def _get_frame(self, seq_path, frame_id):    
        #try:
        frame_path_v = os.path.join(seq_path, 'vis_imgs', sorted([p for p in os.listdir(os.path.join(seq_path, 'vis_imgs')) if os.path.splitext(p)[1] in ['.png','.jpg','.bmp']])[frame_id])
        #frame_path_e = os.path.join(seq_path, 'event_imgs', sorted([p for p in os.listdir(os.path.join(seq_path, 'event_imgs')) if os.path.splitext(p)[1] in ['.jpg','.png','.bmp']])[frame_id])
        frame_path_e = os.path.join(seq_path, 'vis_imgs', sorted([p for p in os.listdir(os.path.join(seq_path, 'vis_imgs')) if os.path.splitext(p)[1] in ['.jpg','.png','.bmp']])[frame_id])
                
        # except(IndexError)        
        # except(IndexError):
            # print("seq_path",seq_path) 
        frame_path_v=self.image_loader(frame_path_v)
        w,h=frame_path_v.shape[0],frame_path_v.shape[1]
        frame_path_e=self.image_loader(frame_path_e,w,h)        
        #pdb.set_trace()
        return frame_path_v,frame_path_e
        

    def get_frames(self, seq_id, frame_ids, anno=None):
        #print(self.sequence_list,self.sequence_list[seq_id])
        seq_name = self.sequence_list[seq_id]
        seq_path = os.path.join(self.root, seq_name)
        frame_list_v=[]
        frame_list_e=[]
        for f in frame_ids:
            frame_path_v = os.path.join(seq_path, 'vis_imgs', sorted([p for p in os.listdir(os.path.join(seq_path, 'vis_imgs')) if os.path.splitext(p)[1] in ['.png','.jpg','.bmp']])[f])
            frame_path_e = os.path.join(seq_path, 'event_imgs', sorted([p for p in os.listdir(os.path.join(seq_path, 'event_imgs')) if os.path.splitext(p)[1] in ['.jpg','.png','.bmp']])[f])
            im = cv.imread(frame_path_v, cv.IMREAD_COLOR)        
            # convert to rgb and return
            frame_v=cv.cvtColor(im, cv.COLOR_BGR2RGB)
            w, h = frame_v.shape[0],frame_v.shape[1]            
            try:
                im = cv.imread(frame_path_e, cv.IMREAD_COLOR)
                frame_e=cv.cvtColor(im, cv.COLOR_BGR2RGB)
                if im.shape[0]!=w or im.shape[1]!=h:
                   frame_e=cv.resize(frame_e,(h,w))
            except:
                print('ERROR: Could not read image "{}"'.format(frame_path_e)) 
            frame_list_v.append(frame_v)
            frame_list_e.append(frame_e)
            
        #print(frame_list_v[0].shape,frame_list_e[0].shape,len(frame_list_v),len(frame_list_e))
        #frame_list_e = [self._get_frame_e(seq_path, f) for f in frame_ids]
        frame_list  = frame_list_v + frame_list_e # 6
        #print('get_frames frame_list', len(frame_list))
        if anno is None:
            anno = self.get_sequence_info(seq_path)

        anno_frames = {}
        for key, value in anno.items():
            anno_frames[key] = [value[f_id, ...].clone() for f_id in frame_ids]

        object_meta = OrderedDict({'object_class_name': None,
                                   'motion_class': None,
                                   'major_class': None,
                                   'root_class': None,
                                   'motion_adverb': None})

        #return frame_list_v, frame_list_i, anno_frames, object_meta
        return frame_list, anno_frames, object_meta
