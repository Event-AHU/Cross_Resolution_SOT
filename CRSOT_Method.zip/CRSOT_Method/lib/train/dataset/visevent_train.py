import torch
import os
import os.path
import numpy as np
import pandas
import random
from collections import OrderedDict
import cv2 as cv
from lib.train.data import jpeg4py_loader,jpeg4py_loader_w_failsafe
from .base_video_dataset import BaseVideoDataset
from lib.train.admin import env_settings
import pdb
class VISEVENT_TRAIN(BaseVideoDataset):
    def __init__(self, root=None, image_loader=jpeg4py_loader_w_failsafe, data_fraction=None):
        self.root = env_settings().visevent_dir if root is None else root
        super().__init__('VISEVENT_TRAIN', root, image_loader)

        # video_name for each sequence
        #self.sequence_list = os.listdir(self.root)
        self.sequence_list =['00358_UAV_outdoor6', 'video_0044', 'dvSave-2021_02_14_16_48_45_car1', 'video_0068', 'dvSave-2021_02_15_23_50_33', 'dvSave-2021_02_06_17_32_42_personBasketball', 'video_0081', 'traffic_0059', 'dvSave-2021_02_06_17_56_47_personFootball', 'dvSave-2021_02_14_16_43_54_car3', 'dvSave-2021_02_06_17_50_24_personBasketball', 'dvSave-2021_02_14_16_56_18_motor1', 'dvSave-2021_02_08_21_02_13_car4', 'dvSave-2021_02_15_13_08_49_whitecar', 'dvSave-2021_02_04_20_44_52', '00405_UAV_outdoor6', 'dvSave-2021_02_06_17_13_57_car', 'dvSave-2021_02_16_17_08_43', 'dvSave-2021_02_15_23_53_35', 'dvSave-2021_02_14_16_40_59_car8', 'dvSave-2021_02_14_16_56_18_car1', 'dvSave-2021_02_14_16_37_15_car4', 'dvSave-2021_02_06_17_21_01_personFootball', 'dvSave-2021_02_15_13_13_11_motor', '00438_UAV_outdoor6', 'dvSave-2021_02_14_16_43_23_car5', 'video_0078', 'dvSave-2021_02_14_16_48_45_car9', '00487_UAV_outdoor6', 'dvSave-2021_02_04_21_20_39', 'dvSave-2021_02_14_16_26_44_car4', '00356_UAV_outdoor6', '00477_UAV_outdoor6', 'video_0014', '00338_UAV_outdoor6', 'dvSave-2021_02_14_16_26_44_car6', 'dvSave-2021_02_06_09_13_36_person1', 'dvSave-2021_02_08_21_17_43_car4', '00489_UAV_outdoor6', 'dvSave-2021_02_14_16_37_15_motor1', 'dvSave-2021_02_06_09_10_52_car4', 'dvSave-2021_02_15_12_49_32_personHead', 'dvSave-2021_02_08_21_04_56_car5', '00444_UAV_outdoor6', '00429_UAV_outdoor6', 'video_0038', 'dvSave-2021_02_06_09_24_39_person3', 'dvSave-2021_02_14_16_42_14_car2', '00493_UAV_outdoor6', 'video_0052', '00456_UAV_outdoor6', 'traffic_0069', '00426_UAV_outdoor6', 'dvSave-2021_02_08_21_02_13_car2', 'dvSave-2021_02_08_21_07_02_car8', '00145_tank_outdoor2', 'dvSave-2021_02_14_16_56_59_car3', 'dvSave-2021_02_08_21_06_03_car4', 'dvSave-2021_02_14_16_26_44_car15', 'traffic_0020', 'traffic_0010', 'dvSave-2021_02_14_17_00_02', 'dvSave-2021_02_06_09_14_18_person3', '00354_UAV_outdoor6', 'dvSave-2021_02_06_15_12_59_car', 'traffic_0001', 'dvSave-2021_02_04_21_21_05', '00384_UAV_outdoor6', 'video_0030', 'dvSave-2021_02_06_09_33_23_person4', '00375_UAV_outdoor6', 'dvSave-2021_02_15_13_08_35_whitecar', 'dvSave-2021_02_15_13_12_56_motor', 'traffic_0030', '00317_UAV_outdoor5', '00293_tennis_outdoor4', 'traffic_0011', 'traffic_0002', 'traffic_0068', 'dvSave-2021_02_16_17_13_20', 'dvSave-2021_02_14_16_46_34_car11', 'traffic_0021', 'traffic_0047', 'video_0069', 'dvSave-2021_02_06_09_23_50_person3', 'dvSave-2021_02_15_12_55_10_Fish', 'dvSave-2021_02_15_12_56_33_person', 'dvSave-2021_02_14_16_26_44_motor2', 'dvSave-2021_02_14_16_37_15_motor3', '00341_UAV_outdoor6', 'video_0057', 'video_0071', '00287_tennis_outdoor4', 'traffic_0053', 'basketball_0077', 'dvSave-2021_02_14_16_30_20_blackcar', 'dvSave-2021_02_06_10_10_50_paperClip', 'traffic_0025', 'video_0031', 'dvSave-2021_02_06_17_28_56_personFootball', 'dvSave-2021_02_14_16_46_34_car14', '00515_person_outdoor6', 'dvSave-2021_02_12_13_43_02', 'dvSave-2021_02_08_21_15_49_car9', 'dvSave-2021_02_14_16_40_59_car3', 'dvSave-2021_02_06_09_11_41_person3', 'dvSave-2021_02_16_17_31_23', 'dvSave-2021_02_16_17_35_49', 'dvSave-2021_02_14_16_30_20_car1', '00334_UAV_outdoor5', 'traffic_0033', 'dvSave-2021_02_14_16_40_59_motor2', 'dvSave-2021_02_14_16_40_59_car2', 'dvSave-2021_02_15_13_11_17_person', '00420_UAV_outdoor6', 'dvSave-2021_02_08_21_02_13_car7', 'dvSave-2021_02_16_17_18_39', 'dvSave-2021_02_06_17_22_16_personFootball', 'video_0016', 'dvSave-2021_02_16_17_21_12', 'traffic_0048', 'dvSave-2021_02_06_09_13_36_person5', 'traffic_0008', 'dvSave-2021_02_15_13_13_56_whitecar', 'traffic_0029', 'traffic_0054', 'dvSave-2021_02_08_21_07_02_car1', 'dvSave-2021_02_06_09_13_36_person7', 'dvSave-2021_02_06_09_09_44_person1', 'dvSave-2021_02_08_21_07_02_car9', '00513_person_outdoor6', 'dvSave-2021_02_14_16_26_44_car9', 'traffic_0004', 'dvSave-2021_02_08_21_15_49_car6', 'video_0042', 'dvSave-2021_02_16_17_39_41', 'dvSave-2021_02_14_16_26_44_car11', 'dvSave-2021_02_08_21_07_02_car3', 'dvSave-2021_02_15_23_52_39', '00389_UAV_outdoor6', 'dvSave-2021_02_14_16_40_59_motor3', 'traffic_0062', 'dvSave-2021_02_06_09_34_36_car', '00366_UAV_outdoor6', '00507_person_outdoor6', 'video_0072', 'dvSave-2021_02_14_16_29_49_car3', '00476_UAV_outdoor6', 'dvSave-2021_02_14_16_46_34_car17', 'dvSave-2021_02_14_16_45_13_car3', 'dvSave-2021_02_16_17_06_53', '00452_UAV_outdoor6', 'dvSave-2021_02_14_16_39_03_person', 'video_0010', '00414_UAV_outdoor6', '00349_UAV_outdoor6', '00440_UAV_outdoor6', 'dvSave-2021_02_08_21_06_03_car1', 'dvSave-2021_02_06_17_26_55_personFootball', 'video_0047', '00504_UAV_outdoor6', 'dvSave-2021_02_08_21_15_49_car12', 'dvSave-2021_02_14_16_48_45_car7', 'dvSave-2021_02_06_09_13_36_person4', 'dvSave-2021_02_14_16_46_34_car9', '00243_tennis_outdoor4', 'dvSave-2021_02_16_17_17_39', '00380_UAV_outdoor6', 'dvSave-2021_02_06_10_07_32_phone', '00512_person_outdoor6', '00303_UAV_outdoor5', 'dvSave-2021_02_14_16_28_37_car4', 'dvSave-2021_02_04_21_19_14', 'traffic_0045', 'dvSave-2021_02_08_21_04_56_car1', 'dvSave-2021_02_06_09_09_44_car1', '00344_UAV_outdoor6', 'dvSave-2021_02_16_17_40_50', 'dvSave-2021_02_16_17_14_59', 'dvSave-2021_02_06_15_17_59_whitecar', 'dvSave-2021_02_14_16_46_34_car7', '00320_UAV_outdoor5', 'dvSave-2021_02_14_16_42_44_car5', '00395_UAV_outdoor6', 'traffic_0027', 'dvSave-2021_02_04_21_01_21', 'dvSave-2021_02_14_16_31_07_blackcar3', '00446_UAV_outdoor6', 'video_0006', 'dvSave-2021_02_14_16_31_07_whitecar3', 'dvSave-2021_02_14_16_26_44_car8', 'traffic_0012', 'video_0037', 'dvSave-2021_02_08_21_04_56_motor1', 'dvSave-2021_02_15_10_24_59', 'dvSave-2021_02_06_09_16_59_car', 'dvSave-2021_02_14_16_46_34_car15', 'dvSave-2021_02_06_17_40_00_personBasketball', '00457_UAV_outdoor6', 'dvSave-2021_02_14_16_48_45_car10', 'dvSave-2021_02_06_09_23_50_person2', 'dvSave-2021_02_06_09_24_39_person2', 'dvSave-2021_02_14_16_26_44_car12', 'dvSave-2021_02_08_21_17_43_car2', '00146_tank_outdoor2', 'video_0034', 'video_0048', 'traffic_0036', 'traffic_0063', 'dvSave-2021_02_08_21_02_13_motor1', 'dvSave-2021_02_08_21_02_13_car6', '00409_UAV_outdoor6', 'dvSave-2021_02_14_16_51_21_person1', 'dvSave-2021_02_12_13_50_26', 'dvSave-2021_02_15_13_23_36_girlhead', 'dvSave-2021_02_06_09_33_23_person3', 'dvSave-2021_02_06_17_39_38_personBasketball', 'dvSave-2021_02_14_16_48_45_car6', '00424_UAV_outdoor6', 'dvSave-2021_02_06_10_15_51_paperClipBox', 'dvSave-2021_02_14_16_43_23_car2', 'dvSave-2021_02_06_09_09_44_person9', 'dvSave-2021_02_06_09_09_44_person2', 'dvSave-2021_02_06_09_24_26_Pedestrian2', 'video_0011', 'dvSave-2021_02_14_16_56_18_car5', 'video_0051', 'dvSave-2021_02_08_21_04_07_motor', 'video_0013', 'video_0066', 'dvSave-2021_02_14_16_28_37_car1', '00496_UAV_outdoor6', 'dvSave-2021_02_14_16_51_21_car3', 'dvSave-2021_02_06_09_24_39_person4', 'dvSave-2021_02_06_09_09_44_person4', 'dvSave-2021_02_04_20_51_32', 'traffic_0005', '00350_UAV_outdoor6', 'dvSave-2021_02_14_16_48_45_car4', 'dvSave-2021_02_14_16_55_10_person', '00148_tank_outdoor2', 'video_0022', 'dvSave-2021_02_08_21_15_49_car2', 'traffic_0018', 'traffic_0007', 'video_0062', '00475_UAV_outdoor6', 'dvSave-2021_02_06_17_45_55_personBasketball', '00376_UAV_outdoor6', '00470_UAV_outdoor6', '00499_UAV_outdoor6', '00411_UAV_outdoor6', 'traffic_0017', 'dvSave-2021_02_14_16_45_13_car4', 'dvSave-2021_02_06_09_33_23_person2', 'traffic_0016', 'dvSave-2021_02_06_09_22_41_person3', 'dvSave-2021_02_06_08_57_00_windowPattern3', '00443_UAV_outdoor6', 'dvSave-2021_02_14_16_56_59_car7', 'dvSave-2021_02_14_16_48_45_car2', 'video_0053', 'video_0080', 'video_0019', 'dvSave-2021_02_14_16_51_57_car1', 'traffic_0075', 'dvSave-2021_02_16_17_37_27', 'dvSave-2021_02_06_09_11_41_car2', 'dvSave-2021_02_14_16_56_18_car3', 'dvSave-2021_02_14_16_46_34_car13', 'dvSave-2021_02_14_16_34_11_car2', 'dvSave-2021_02_14_16_51_21_car2', 'dvSave-2021_02_14_16_43_23_car1', 'dvSave-2021_02_08_21_15_49_car7', '00273_tennis_outdoor4', '00463_UAV_outdoor6', 'dvSave-2021_02_08_21_04_56_car4', 'dvSave-2021_02_14_16_22_05', 'traffic_0072', 'basketball_0079', 'dvSave-2021_02_14_16_45_13_car2', 'dvSave-2021_02_06_09_23_50_car1', 'dvSave-2021_02_08_21_02_13_car1', '00239_tennis_outdoor4', 'dvSave-2021_02_14_16_31_07_whitecar2', 'dvSave-2021_02_08_21_07_02_car4', 'dvSave-2021_02_16_17_27_35', '00360_UAV_outdoor6', 'dvSave-2021_02_06_09_11_41_car3', '00450_UAV_outdoor6', 'dvSave-2021_02_14_16_51_21_car5', 'dvSave-2021_02_06_09_14_18_person4', 'traffic_0065', 'dvSave-2021_02_08_21_15_49_car10', '00283_tennis_outdoor4', 'dvSave-2021_02_14_16_31_07_blackcar1', 'dvSave-2021_02_12_13_49_16', '00328_UAV_outdoor5', 'dvSave-2021_02_06_10_01_02_GreenPlant', '00371_UAV_outdoor6', 'dvSave-2021_02_16_17_00_10', 'dvSave-2021_02_14_16_45_13_car8', 'dvSave-2021_02_06_09_14_18_person2', 'dvSave-2021_02_14_16_46_34_car1', 'video_0061', 'dvSave-2021_02_14_17_02_37', 'dvSave-2021_02_16_17_22_03', 'dvSave-2021_02_14_16_26_44_car5', 'dvSave-2021_02_14_16_43_54_car1', '00417_UAV_outdoor6', 'dvSave-2021_02_14_16_56_59_car5', 'video_0046', 'dvSave-2021_02_08_21_06_03_motor1', 'dvSave-2021_02_12_14_00_54', '00436_UAV_outdoor6', 'video_0025', 'dvSave-2021_02_06_09_23_50_car', '00142_tank_outdoor2', 'video_0074', '00486_UAV_outdoor6', 'dvSave-2021_02_04_21_18_14', 'dvSave-2021_02_06_09_11_41_person2', 'dvSave-2021_02_08_21_15_49_car4', 'dvSave-2021_02_06_17_55_39_personFootball', 'dvSave-2021_02_14_16_26_44_car1', 'dvSave-2021_02_14_16_39_36_person', 'dvSave-2021_02_06_09_13_36_person3', 'traffic_0022', 'dvSave-2021_02_14_16_26_44_motor3', 'dvSave-2021_02_06_09_14_18_person1', 'dvSave-2021_02_14_16_35_40_car3', 'video_0017', 'dvSave-2021_02_08_21_06_03_car2', 'video_0040', 'dvSave-2021_02_15_13_04_29_Chicken', 'dvSave-2021_02_14_16_35_40_car1', 'dvSave-2021_02_06_09_21_41_person', 'dvSave-2021_02_14_16_45_13_car6', '00337_UAV_outdoor6', 'dvSave-2021_02_06_09_15_54_car', 'dvSave-2021_02_14_16_26_44_car13', 'dvSave-2021_02_14_16_34_11_car1', 'dvSave-2021_02_15_13_07_58_car', '00393_UAV_outdoor6', 'dvSave-2021_02_06_17_29_32_personFootball', 'video_0059', 'dvSave-2021_02_06_17_16_12_taxi', 'dvSave-2021_02_04_21_07_26', '00505_UAV_outdoor6', 'video_0043', 'dvSave-2021_02_06_09_13_36_person6', 'dvSave-2021_02_14_16_37_15_car6', 'dvSave-2021_02_14_16_26_44_car10', 'traffic_0057', 'dvSave-2021_02_06_17_46_58_personBasketball', 'video_0012', 'dvSave-2021_02_06_17_35_50_personBasketball', 'traffic_0051', 'dvSave-2021_02_08_21_07_02_car5', 'dvSave-2021_02_14_16_46_34_car2', '00396_UAV_outdoor6', 'video_0007', 'dvSave-2021_02_08_21_17_43_car1', 'dvSave-2021_02_06_09_09_44_person8', '00144_tank_outdoor2', 'dvSave-2021_02_08_21_04_56_car8', 'video_0027', '00330_UAV_outdoor5', 'dvSave-2021_02_06_15_13_56_blackcar', 'dvSave-2021_02_06_17_22_47_personFootball', '00498_UAV_outdoor6', 'traffic_0041', 'traffic_0050', 'video_0055', 'traffic_0035', 'dvSave-2021_02_12_14_00_12', 'traffic_0014', 'dvSave-2021_02_04_20_55_01', 'dvSave-2021_02_12_13_53_23', '00412_UAV_outdoor6', 'dvSave-2021_02_08_21_15_49_car11', 'video_0003', 'dvSave-2021_02_08_21_02_13_car8', 'dvSave-2021_02_14_16_29_49_car1', '00491_UAV_outdoor6', 'dvSave-2021_02_06_17_16_57_whitecar', '00509_person_outdoor6', 'dvSave-2021_02_14_16_43_54_car5', '00367_UAV_outdoor6', '00300_tennis_outdoor4', 'dvSave-2021_02_06_17_54_47_personFootball', 'dvSave-2021_02_08_21_07_02_car6', '00333_UAV_outdoor5', 'dvSave-2021_02_15_23_55_00', 'dvSave-2021_02_15_13_12_13_whitecar', 'video_0075', 'dvSave-2021_02_06_17_14_12_whitecar', '00407_UAV_outdoor6', '00461_UAV_outdoor6', 'traffic_0071', 'dvSave-2021_02_14_16_26_44_car7', 'dvSave-2021_02_12_13_41_58', '00372_UAV_outdoor6', 'dvSave-2021_02_15_23_55_54', 'dvSave-2021_02_04_20_46_47', 'traffic_0044', 'dvSave-2021_02_06_09_09_44_person5', 'dvSave-2021_02_12_13_44_51', 'dvSave-2021_02_15_12_58_05_personHead1', 'dvSave-2021_02_14_16_43_54_car6', 'video_0028', 'dvSave-2021_02_06_17_33_56_personBasketball', 'dvSave-2021_02_16_17_26_14', 'traffic_0074', 'traffic_0056', 'dvSave-2021_02_14_16_40_59_car5', 'traffic_0038', 'video_0077', 'dvSave-2021_02_06_17_58_59_personFootball', 'dvSave-2021_02_14_16_37_15_car3', 'dvSave-2021_02_14_16_37_15_car1', 'traffic_0009', 'traffic_0039', '00296_tennis_outdoor4', '00422_UAV_outdoor6', '00359_UAV_outdoor6', '00472_UAV_outdoor6', 'dvSave-2021_02_14_16_44_29_car1', 'traffic_0066', 'dvSave-2021_02_08_21_02_13_car9', 'traffic_0042', 'dvSave-2021_02_14_16_26_44_car14', 'dvSave-2021_02_12_13_37_11', 'dvSave-2021_02_08_21_15_49_car5', 'dvSave-2021_02_16_17_32_33', 'dvSave-2021_02_14_16_46_34_car6', '00415_UAV_outdoor6', 'dvSave-2021_02_08_21_06_03_car6', '00150_tank_outdoor2', 'dvSave-2021_02_15_10_26_52_personHead2', 'dvSave-2021_02_04_21_19_24', '00237_tennis_outdoor4', 'traffic_0031', 'video_0035', 'traffic_0024', 'dvSave-2021_02_14_16_26_44_car16', 'dvSave-2021_02_08_21_07_02_car7', 'dvSave-2021_02_08_21_02_13_car5', 'dvSave-2021_02_06_17_42_26_personBasketball', '00482_UAV_outdoor6', '00149_tank_outdoor2', 'dvSave-2021_02_16_17_10_40', '00488_UAV_outdoor6', 'traffic_0060', 'dvSave-2021_02_14_16_34_48_car1', 'dvSave-2021_02_15_13_10_23_person', 'dvSave-2021_02_14_16_56_59_car1', 'traffic_0015', 'dvSave-2021_02_06_09_22_41_person2', 'video_0065', '00479_UAV_outdoor6', '00390_UAV_outdoor6', 'dvSave-2021_02_04_20_59_21', '00454_UAV_outdoor6', 'dvSave-2021_02_14_16_26_44_motor1', '00418_UAV_outdoor6', 'dvSave-2021_02_14_16_51_21_car4', '00431_UAV_outdoor6', 'dvSave-2021_02_08_21_04_56_car2', 'dvSave-2021_02_08_21_08_12', 'video_0023', 'dvSave-2021_02_14_16_46_34_car4', '00501_UAV_outdoor6', 'traffic_0032', 'dvSave-2021_02_15_13_24_21_girlhead', 'dvSave-2021_02_14_16_42_44_car4', 'dvSave-2021_02_14_16_26_44_car2', 'dvSave-2021_02_06_09_33_23_person6', 'dvSave-2021_02_08_21_04_56_car7', 'video_0036', '00143_tank_outdoor2', 'dvSave-2021_02_14_16_30_20_car3', 'dvSave-2021_02_15_10_15_28_person', '00434_UAV_outdoor6', 'dvSave-2021_02_06_10_12_48_paperClip', 'traffic_0003', 'video_0002', '00403_UAV_outdoor6', 'dvSave-2021_02_06_18_04_18_person2', '00391_UAV_outdoor6', 'dvSave-2021_02_14_16_40_59_car6', '00448_UAV_outdoor6', 'dvSave-2021_02_06_17_24_22_personFootball', 'dvSave-2021_02_06_15_15_15_person', '00465_UAV_outdoor6', 'dvSave-2021_02_14_16_37_15_motor4', 'dvSave-2021_02_06_17_44_35_personBasketball', 'dvSave-2021_02_15_13_25_17_girlhead', '00441_UAV_outdoor6', '00298_tennis_outdoor4']

        if data_fraction is not None:
            self.sequence_list = random.sample(self.sequence_list, int(len(self.sequence_list) * data_fraction))
        
    def get_name(self):
        return 'visevent_train'
    def get_num_sequences(self):
        return len(self.sequence_list)
    def _read_bb_anno(self, seq_path):
        bb_anno_file = os.path.join(seq_path, 'groundtruth.txt')
        gt = pandas.read_csv(bb_anno_file, delimiter=',', header=None, dtype=np.float32, na_filter=False,
                             low_memory=False).values
        return torch.tensor(gt)

    def get_sequence_info(self, seq_id):
        seq_name = self.sequence_list[seq_id]
        seq_path = os.path.join(self.root, seq_name)
        bbox = self._read_bb_anno(seq_path)

        valid = (bbox[:, 2] > 0) & (bbox[:, 3] > 0)
        visible = valid.clone().byte()
        #print("bbox",len(visible))        
        return {'bbox': bbox, 'valid': valid, 'visible': visible}

    def _get_frame(self, seq_path, frame_id):    
        #try:
        frame_path_v = os.path.join(seq_path, 'vis_imgs', sorted([p for p in os.listdir(os.path.join(seq_path, 'vis_imgs')) if os.path.splitext(p)[1] in ['.png','.jpg','.bmp']])[frame_id])
        frame_path_e = os.path.join(seq_path, 'event_imgs', sorted([p for p in os.listdir(os.path.join(seq_path, 'event_imgs')) if os.path.splitext(p)[1] in ['.jpg','.png','.bmp']])[frame_id])
        #frame_path_e = os.path.join(seq_path, 'vis_imgs', sorted([p for p in os.listdir(os.path.join(seq_path, 'vis_imgs')) if os.path.splitext(p)[1] in ['.jpg','.png','.bmp']])[frame_id])
                
        # except(IndexError)        
        # except(IndexError):
            # print("seq_path",seq_path) 
        frame_path_v=self.image_loader(frame_path_v)
        w,h=frame_path_v.shape[0],frame_path_v.shape[1]
        frame_path_e=self.image_loader(frame_path_e,w,h)        
        #pdb.set_trace()
        return frame_path_v,frame_path_e
        

    def get_frames(self, seq_id, frame_ids, anno=None):
        #print(self.sequence_list,self.sequence_list[seq_id])
        seq_name = self.sequence_list[seq_id]
        seq_path = os.path.join(self.root, seq_name)
        frame_list_v=[]
        frame_list_e=[]
        #pdb.set_trace()
        for f in frame_ids:
            frame_path_v = os.path.join(seq_path, 'vis_imgs', sorted([p for p in os.listdir(os.path.join(seq_path, 'vis_imgs')) if os.path.splitext(p)[1] in ['.png','.jpg','.bmp']])[f])
            frame_path_e = os.path.join(seq_path, 'event_imgs', sorted([p for p in os.listdir(os.path.join(seq_path, 'event_imgs')) if os.path.splitext(p)[1] in ['.jpg','.png','.bmp']])[f])
            im = cv.imread(frame_path_v, cv.IMREAD_COLOR)        
            # convert to rgb and return
            frame_v=cv.cvtColor(im, cv.COLOR_BGR2RGB)
            w, h = frame_v.shape[0],frame_v.shape[1]            
            try:
                im = cv.imread(frame_path_e, cv.IMREAD_COLOR)
                frame_e=cv.cvtColor(im, cv.COLOR_BGR2RGB)
                if im.shape[0]!=w or im.shape[1]!=h:
                   frame_e=cv.resize(frame_e,(h,w))
            except:
                print('ERROR: Could not read image "{}"'.format(frame_path_e)) 
            frame_list_v.append(frame_v)
            frame_list_e.append(frame_e)
            
        #print(frame_list_v[0].shape,frame_list_e[0].shape,len(frame_list_v),len(frame_list_e))
        #frame_list_e = [self._get_frame_e(seq_path, f) for f in frame_ids]
        frame_list  = frame_list_v + frame_list_e # 6
        #print('get_frames frame_list', len(frame_list))
        if anno is None:
            anno = self.get_sequence_info(seq_path)

        anno_frames = {}
        for key, value in anno.items():
            anno_frames[key] = [value[f_id, ...].clone() for f_id in frame_ids]

        object_meta = OrderedDict({'object_class_name': None,
                                   'motion_class': None,
                                   'major_class': None,
                                   'root_class': None,
                                   'motion_adverb': None})

        #return frame_list_v, frame_list_i, anno_frames, object_meta
        return frame_list, anno_frames, object_meta
