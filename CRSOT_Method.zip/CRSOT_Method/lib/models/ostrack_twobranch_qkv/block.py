import torch.nn as nn
from timm.models.layers import Mlp, DropPath, trunc_normal_, lecun_normal_
from lib.models.layers.attn_blocks import candidate_elimination
from .attention import Attention_qkv
# from torch.nn.functional import *
import torch
import torch.nn.functional as F



# class CEBlock(nn.Module):

#     def __init__(self, dim, num_heads, mlp_ratio=4., qkv_bias=False, drop=0., attn_drop=0.,
#                  drop_path=0., act_layer=nn.GELU, norm_layer=nn.LayerNorm, keep_ratio_search=1.0,
#                 layer_num=None):
#         super().__init__()

#         self.layer_num = layer_num
#         self.area = None
        
#         self.norm1 = norm_layer(dim)
#         self.attn = Attention_qkv(dim, num_heads=num_heads, qkv_bias=qkv_bias, attn_drop=attn_drop, proj_drop=drop)

#         # NOTE: drop path for stochastic depth, we shall see if this is better than dropout here
#         self.drop_path = DropPath(drop_path) if drop_path > 0. else nn.Identity()
#         self.norm2 = norm_layer(dim)

#         mlp_hidden_dim = int(dim * mlp_ratio)
#         self.mlp = Mlp(in_features=dim, hidden_features=mlp_hidden_dim, act_layer=act_layer, drop=drop)

#         self.keep_ratio_search = keep_ratio_search


#     def keep_token(self, x, attn, global_index_template=None, global_index_search=None, \
#                    ce_template_mask=None, keep_ratio_search=None):
        
#         lens_t = global_index_template.shape[1]
#         removed_index_search = None
#         if self.keep_ratio_search < 1 and (keep_ratio_search is None or keep_ratio_search < 1):
#             keep_ratio_search = self.keep_ratio_search if keep_ratio_search is None else keep_ratio_search
#             x, global_index_search, removed_index_search = \
#                 candidate_elimination(attn, x, lens_t, keep_ratio_search, global_index_search, ce_template_mask)

#         return x, global_index_template, global_index_search, removed_index_search


#     def forward(self, x_rgb, x_tir, global_index_t, global_index_s, mask, 
#                 ce_template_mask, keep_ratio_search):
        
#         x_rgb_attn, corrmap_rgb = self.attn(self.norm1(x_rgb), mask=mask, return_attention=True)
#         x_tir_attn, corrmap_tir = self.attn(self.norm1(x_tir), mask=mask, return_attention=True)

#         # 残差连接
#         x_rgb = x_rgb + self.drop_path(x_rgb_attn)
#         x_tir = x_tir + self.drop_path(x_tir_attn)

#         # 去除冗余块
#         attn_all = corrmap_rgb+corrmap_tir
#         x_rgb, _, _, _ = \
#             self.keep_token(x_rgb, attn_all, global_index_t, global_index_s, ce_template_mask, keep_ratio_search)
#         x_tir, global_index_t, global_index_s, removed_index_s = \
#             self.keep_token(x_tir, attn_all, global_index_t, global_index_s, ce_template_mask, keep_ratio_search)

#         # 通道注意力
#         x_rgb = x_rgb + self.drop_path(self.mlp(self.norm2(x_rgb)))
#         x_tir = x_tir + self.drop_path(self.mlp(self.norm2(x_tir)))

#         return x_rgb, x_tir, global_index_t, global_index_s, removed_index_s, corrmap_rgb, corrmap_tir








class Block(nn.Module):

    def __init__(self, dim, num_heads, mlp_ratio=4., qkv_bias=False, drop=0., attn_drop=0.,
                 drop_path=0., act_layer=nn.GELU, norm_layer=nn.LayerNorm,
                layer_num=None):
        super().__init__()

        self.layer_num = layer_num
        self.area = None
        
        self.norm1 = norm_layer(dim)
        self.attn = Attention_qkv(dim, num_heads=num_heads, qkv_bias=qkv_bias, attn_drop=attn_drop, proj_drop=drop)

        # NOTE: drop path for stochastic depth, we shall see if this is better than dropout here
        self.drop_path = DropPath(drop_path) if drop_path > 0. else nn.Identity()
        self.norm2 = norm_layer(dim)

        mlp_hidden_dim = int(dim * mlp_ratio)
        self.mlp = Mlp(in_features=dim, hidden_features=mlp_hidden_dim, act_layer=act_layer, drop=drop)


    def forward(self, x_rgb, x_tir, mask):
        
        x_rgb_attn, corrmap_rgb = self.attn(self.norm1(x_rgb), mask=mask, return_attention=True)
        x_tir_attn, corrmap_tir = self.attn(self.norm1(x_tir), mask=mask, return_attention=True)

        # 残差连接
        x_rgb = x_rgb + self.drop_path(x_rgb_attn)
        x_tir = x_tir + self.drop_path(x_tir_attn)

        # 通道注意力
        x_rgb = x_rgb + self.drop_path(self.mlp(self.norm2(x_rgb)))
        x_tir = x_tir + self.drop_path(self.mlp(self.norm2(x_tir)))

        return x_rgb, x_tir, corrmap_rgb, corrmap_tir





class CEBlock(nn.Module):

    def __init__(self, dim, num_heads, mlp_ratio=4., qkv_bias=False, drop=0., attn_drop=0.,
                 drop_path=0., act_layer=nn.GELU, norm_layer=nn.LayerNorm, keep_ratio_search=1.0):
        super().__init__()

        self.norm1 = norm_layer(dim)
        self.attn = Attention_qkv(dim, num_heads=num_heads, qkv_bias=qkv_bias, attn_drop=attn_drop, proj_drop=drop)

        # NOTE: drop path for stochastic depth, we shall see if this is better than dropout here
        self.drop_path = DropPath(drop_path) if drop_path > 0. else nn.Identity()
        self.norm2 = norm_layer(dim)

        mlp_hidden_dim = int(dim * mlp_ratio)
        self.mlp = Mlp(in_features=dim, hidden_features=mlp_hidden_dim, act_layer=act_layer, drop=drop)

        self.keep_ratio_search = keep_ratio_search


    def attn_forward(self, x, mask=None, attn_o=None):
        x_attn, attn = self.attn(self.norm1(x), mask=mask, return_attention=True)
        x = x + self.drop_path(x_attn)
        return x, attn


    def keep_token(self, x, attn, \
                   global_index_template=None, global_index_search=None, \
                   ce_template_mask=None, keep_ratio_search=None):
        
        lens_t = global_index_template.shape[1]
        removed_index_search = None
        if self.keep_ratio_search < 1 and (keep_ratio_search is None or keep_ratio_search < 1):
            keep_ratio_search = self.keep_ratio_search if keep_ratio_search is None else keep_ratio_search
            x, global_index_search, removed_index_search = \
                candidate_elimination(attn, x, lens_t, keep_ratio_search, global_index_search, ce_template_mask)

        return x, global_index_template, global_index_search, removed_index_search


    def mlp_forward(self, x):
        x = x + self.drop_path(self.mlp(self.norm2(x)))
        return x

    def forward_ceblock(self,   x_rgb, global_index_t_rgb, global_index_s_rgb, \
                                x_tir, global_index_t_tir, global_index_s_tir, \
                                mask, ce_template_mask, keep_ratio_search):
        
        x_rgb, attn_rgb = self.attn_forward(x_rgb, mask=mask)
        x_tir, attn_tir = self.attn_forward(x_tir, mask=mask)

        # 去除冗余块
        attn_all = attn_rgb+attn_tir
        x_rgb, global_index_t_rgb, global_index_s_rgb, removed_index_s_rgb = \
            self.keep_token(x_rgb, attn_all, global_index_t_rgb, global_index_s_rgb, ce_template_mask, keep_ratio_search)
        x_tir, global_index_t_tir, global_index_s_tir, removed_index_s_tir = \
            self.keep_token(x_tir, attn_all, global_index_t_tir, global_index_s_tir, ce_template_mask, keep_ratio_search)


        # 通道注意力
        x_rgb = self.mlp_forward(x_rgb)
        x_tir = self.mlp_forward(x_tir)

        return x_rgb, global_index_t_rgb, global_index_s_rgb, removed_index_s_rgb, attn_rgb,\
                x_tir, global_index_t_tir, global_index_s_tir, removed_index_s_tir, attn_tir


    def forward(self, *params):
        return self.forward_ceblock(*params)