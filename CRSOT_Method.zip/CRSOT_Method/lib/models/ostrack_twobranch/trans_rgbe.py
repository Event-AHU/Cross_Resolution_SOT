import torch.nn as nn
import torch
from torch.nn.init import xavier_normal_, constant_, xavier_uniform_
from timm.models.layers import Mlp, DropPath, trunc_normal_, lecun_normal_
class Attention_qkv(nn.Module):
    def __init__(self, dim, num_heads=12, qkv_bias=False, attn_drop=0., proj_drop=0.):
        super().__init__()
        self.num_heads = num_heads
        head_dim = dim // num_heads
        self.scale = head_dim ** -0.5

        self.q_linear = nn.Linear(dim, dim, bias=qkv_bias)
        self.k_linear = nn.Linear(dim, dim, bias=qkv_bias)
        self.v_linear = nn.Linear(dim, dim, bias=qkv_bias)

        self.attn_drop = nn.Dropout(attn_drop)
        self.proj = nn.Linear(dim, dim)
        self.proj_drop = nn.Dropout(proj_drop)


    def get_corrmap(self, q, k, mask):
        """
        输出原始的QK权重，未softmax
        """
        # q: B, N, C
        B, N1, C = q.shape
        B, N2, C = k.shape
        q = self.q_linear(q).reshape(B, N1, self.num_heads, C // self.num_heads).permute(0, 2, 1, 3) # B,hn,N,C/hn
        k = self.k_linear(k).reshape(B, N2, self.num_heads, C // self.num_heads).permute(0, 2, 1, 3)

        attn = (q @ k.transpose(-2, -1)) * self.scale

        if mask is not None:
            attn = attn.masked_fill(mask.unsqueeze(1).unsqueeze(2), float('-inf'),)
        return attn



    def get_attn_x(self, attn, v, return_attention=False, need_softmax=True):
        """
        根据attn权重，组织value
        """
        if need_softmax:        
            attn = attn.softmax(dim=-1)
            
        B,N,C = v.shape
        v = self.v_linear(v).reshape(B, N, self.num_heads, C // self.num_heads).permute(0, 2, 1, 3)

        attn = self.attn_drop(attn)

        x = (attn @ v).transpose(1, 2).reshape(B, -1, C)
        x = self.proj(x)
        x = self.proj_drop(x)

        if return_attention:
            return x, attn
        else:
            return x


    def general_forward(self, query, key, value, mask, return_attention=False):
        # q: B, N, C
        B, N1, C = query.shape
        B, N2, C = key.shape
        q = self.q_linear(query).reshape(B, N1, self.num_heads, C // self.num_heads).permute(0, 2, 1, 3) # B,hn,N,C/hn
        k = self.k_linear(key).reshape(B, N2, self.num_heads, C // self.num_heads).permute(0, 2, 1, 3)
        v = self.v_linear(value).reshape(B, N2, self.num_heads, C // self.num_heads).permute(0, 2, 1, 3)

        attn = (q @ k.transpose(-2, -1)) * self.scale

        if mask is not None:
            attn = attn.masked_fill(mask.unsqueeze(1).unsqueeze(2), float('-inf'),)

        attn = attn.softmax(dim=-1)
        attn = self.attn_drop(attn)

        x = (attn @ v).transpose(1, 2).reshape(B, N1, C)
        x = self.proj(x)
        x = self.proj_drop(x)

        if return_attention:
            return x, attn
        else:
            return x
        

    def forward(self, x_rgb,x_e, mask=None, return_attention=False):
        q=x_rgb
        k=v=x_e
        return self.general_forward(q,k,v,mask, return_attention)


class Trans_rgbe(nn.Module):

    def __init__(self, dim, num_heads, mlp_ratio=4., qkv_bias=False, drop=0., attn_drop=0.,
                 drop_path=0., act_layer=nn.GELU, norm_layer=nn.LayerNorm):
        super().__init__()
        self.norm1 = norm_layer(dim)
        self.norm1_1 = norm_layer(dim)
        self.norm1_tir = norm_layer(dim)
        self.mul_attn = Attention_qkv(dim, num_heads=num_heads, qkv_bias=qkv_bias, attn_drop=attn_drop, proj_drop=drop)
        # NOTE: drop path for stochastic depth, we shall see if this is better than dropout here
        self.drop_path = DropPath(drop_path) if drop_path > 0. else nn.Identity()
        self.norm2 = norm_layer(dim)
        self.norm3 = norm_layer(dim)
        mlp_hidden_dim = int(dim * mlp_ratio)
        self.mlp_mu = Mlp(in_features=dim, hidden_features=mlp_hidden_dim, act_layer=act_layer, drop=drop)
        self.mlp_std = Mlp(in_features=dim, hidden_features=mlp_hidden_dim, act_layer=act_layer, drop=drop)
    def forward(self, x_rgb, x_e, return_attention=False):
        # if return_attention:
            # feat, attn = self.attn(self.norm1(x), True)
            # x = x + self.drop_path(feat)
            # x = x + self.drop_path(self.mlp(self.norm2(x)))
            # return x, attn
        # else:
        x = x_rgb + self.drop_path(self.mul_attn(self.norm1_1(x_rgb), self.norm1(x_e)))
        x_mu = x + self.drop_path(self.mlp_mu(self.norm2(x)))
        x_std = x + self.drop_path(self.mlp_std(self.norm3(x)))        
        x_std = (x_std * 0.5).exp()        
        return x_mu,x_std