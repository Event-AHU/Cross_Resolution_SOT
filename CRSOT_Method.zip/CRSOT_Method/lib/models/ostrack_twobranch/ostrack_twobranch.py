"""
Basic OSTrack model.
"""
import math
import os
from typing import List

import torch
from torch import nn
from torch.nn.modules.transformer import _get_clones

from lib.models.layers.head import build_box_head
from lib.models.ostrack_twobranch.vit import vit_base_patch16_224
from lib.models.ostrack_twobranch.vit_ce import vit_large_patch16_224_ce, vit_base_patch16_224_ce
from lib.utils.box_ops import box_xyxy_to_cxcywh
import pdb
from .trans_fusion import Trans_fusion
from .trans_rgb import Trans_rgb
from .trans_rgbe import Trans_rgbe
class OSTrack_twobranch(nn.Module):
    """ This is the base class for OSTrack """

    def __init__(self, transformer,transformer_rgb, transformer_rgbe, transformer_fusion, box_head, box_head_rgb, box_head_t, aux_loss=False, head_type="CORNER"):
        """ Initializes the model.
        Parameters:
            transformer: torch module of the transformer architecture.
            aux_loss: True if auxiliary decoding losses (loss at each decoder layer) are to be used.
        """
        super().__init__()
        self.backbone = transformer
        #self.backbone_i = transformer_i
        self.box_head = box_head
        self.box_head_rgb = box_head_rgb
        self.box_head_t = box_head_t    
        self.transformer_rgb = transformer_rgb  
        self.transformer_rgbe = transformer_rgbe         
        self.transformer_fusion = transformer_fusion
        self.aux_loss = aux_loss
        self.head_type = head_type
        if head_type == "CORNER" or head_type == "CENTER":
            self.feat_sz_s = int(box_head.feat_sz)
            self.feat_len_s = int(box_head.feat_sz ** 2)

        if self.aux_loss:
            self.box_head = _get_clones(self.box_head, 6)
            self.box_head_rgb = _get_clones(self.box_head_rgb, 6)
            self.box_head_t = _get_clones(self.box_head_t, 6)


    def forward(self, template: torch.Tensor,
                search: torch.Tensor,
                ce_template_mask=None,
                ce_keep_rate=None,
                return_last_attn=False,
                ):
        x_rgb, aux_dict_rgb = self.backbone(z=template[0], x=search[0],
                                    ce_template_mask=ce_template_mask,
                                    ce_keep_rate=ce_keep_rate,
                                    return_last_attn=return_last_attn, )

        x_tir, aux_dict_tir = self.backbone(z=template[1], x=search[1],
                                    ce_template_mask=ce_template_mask,
                                    ce_keep_rate=ce_keep_rate,
                                    return_last_attn=return_last_attn, )

        aux_dict = {'aux_dict_rgb':aux_dict_rgb, 'aux_dict_tir':aux_dict_tir}
        #x = torch.cat([x_rgb,x_tir],2)
        #pdb.set_trace()
        mu_dul_rgb,std_dul_rgb=self.transformer_rgb(x_rgb)
        mu_dul_t,std_dul_t=self.transformer_rgbe(x_rgb, x_tir) 
        #pdb.set_trace() 
        epsilon_rgb = torch.randn_like(std_dul_rgb)
        x_dul_rgb = mu_dul_rgb + epsilon_rgb * std_dul_rgb
        variance_dul_rgb = std_dul_rgb**2

        loss_kl_rgb = ((variance_dul_rgb + mu_dul_rgb**2 - torch.log(variance_dul_rgb) - 1) * 0.5).sum(dim=0).mean()
        #losses_KL.update(loss_kl.item(), inputs.size(0))
        kl_loss_rgb = loss_kl_rgb  

        #pdb.set_trace() 
        epsilon_t = torch.randn_like(std_dul_t)
        x_dul_t = mu_dul_t + epsilon_t * std_dul_t
        variance_dul_t = std_dul_t**2

        loss_kl_t = ((variance_dul_t + mu_dul_t**2 - torch.log(variance_dul_t) - 1) * 0.5).sum(dim=0).mean()
        #losses_KL.update(loss_kl.item(), inputs.size(0))
        kl_loss_t= loss_kl_t 
        # w_t = std_dul_rgb/(std_dul_rgb+std_dul_t)
        # w_rgb = std_dul_t/(std_dul_rgb+std_dul_t)
        # #pdb.set_trace()
        # x_rgb_w = w_rgb*mu_dul_rgb
        # x_t_w = w_t*mu_dul_t        
        x = self.transformer_fusion(x_dul_rgb,x_dul_t)
        
        
        # Forward head
        feat_last = x
        feat_last_rgb = x_dul_rgb
        feat_last_t = x_dul_t        
        if isinstance(x, list):
            feat_last = x[-1]
            feat_last_rgb = x_dul_rgb[-1]       
            feat_last_t = x_dul_t[-1]  
        #pdb.set_trace()
        out = self.forward_head(feat_last, None)
        out_rgb = self.forward_head_rgb(feat_last_rgb, None)
        out_t = self.forward_head_t(feat_last_t, None)        
        out.update(aux_dict)
        out['backbone_feat'] = x
        return out, out_rgb, out_t, kl_loss_rgb, kl_loss_t
    def forward_test(self, template: torch.Tensor,
                search: torch.Tensor,
                ce_template_mask=None,
                ce_keep_rate=None,
                return_last_attn=False,
                ):
        x_rgb, aux_dict_rgb = self.backbone(z=template[0], x=search[0],
                                    ce_template_mask=ce_template_mask,
                                    ce_keep_rate=ce_keep_rate,
                                    return_last_attn=return_last_attn, )

        x_tir, aux_dict_tir = self.backbone(z=template[1], x=search[1],
                                    ce_template_mask=ce_template_mask,
                                    ce_keep_rate=ce_keep_rate,
                                    return_last_attn=return_last_attn, )

        aux_dict = {'aux_dict_rgb':aux_dict_rgb, 'aux_dict_tir':aux_dict_tir}
        #x = torch.cat([x_rgb,x_tir],2)
        #pdb.set_trace()
        
        mu_dul_rgb,std_dul_rgb=self.transformer_rgb(x_rgb)
        mu_dul_t,std_dul_t=self.transformer_rgbe(x_rgb, x_tir)         
        # w_t = std_dul_rgb/(std_dul_rgb+std_dul_t)
        # w_rgb = std_dul_t/(std_dul_rgb+std_dul_t)
        # #pdb.set_trace()
        # x_rgb_w = w_rgb*mu_dul_rgb
        # x_t_w = w_t*mu_dul_t        
        x = self.transformer_fusion(mu_dul_rgb,mu_dul_t)        
        
        #mu_dul,std_dul=self.transformer_fusion(x_rgb,x_tir)
        #pdb.set_trace() 
        # epsilon = torch.randn_like(std_dul)
        # x = mu_dul + epsilon * std_dul
        # variance_dul = std_dul**2

        # loss_kl = ((variance_dul + mu_dul**2 - torch.log(variance_dul) - 1) * 0.5).sum(dim=0).mean()
        # #losses_KL.update(loss_kl.item(), inputs.size(0))
        # kl_loss = loss_kl
        #x=mu_dul
        # Forward head
        feat_last = x
        if isinstance(x, list):
            feat_last = x[-1]
        out = self.forward_head(feat_last, None)

        out.update(aux_dict)
        out['backbone_feat'] = x
        return out
    def forward_head(self, cat_feature, gt_score_map=None):
        """
        cat_feature: output embeddings of the backbone, it can be (HW1+HW2, B, C) or (HW2, B, C)
        """
        enc_opt = cat_feature[:, -self.feat_len_s:]  # encoder output for the search region (B, HW, C)
        opt = (enc_opt.unsqueeze(-1)).permute((0, 3, 2, 1)).contiguous()
        bs, Nq, C, HW = opt.size()
        opt_feat = opt.view(-1, C, self.feat_sz_s, self.feat_sz_s)

        if self.head_type == "CORNER":
            # run the corner head
            pred_box, score_map = self.box_head(opt_feat, True)
            outputs_coord = box_xyxy_to_cxcywh(pred_box)
            outputs_coord_new = outputs_coord.view(bs, Nq, 4)
            out = {'pred_boxes': outputs_coord_new,
                   'score_map': score_map,
                   }
            return out

        elif self.head_type == "CENTER":
            # run the center head
            score_map_ctr, bbox, size_map, offset_map = self.box_head(opt_feat, gt_score_map)
            # outputs_coord = box_xyxy_to_cxcywh(bbox)
            outputs_coord = bbox
            outputs_coord_new = outputs_coord.view(bs, Nq, 4)
            out = {'pred_boxes': outputs_coord_new,
                   'score_map': score_map_ctr,
                   'size_map': size_map,
                   'offset_map': offset_map}
            return out
        else:
            raise NotImplementedError
    def forward_head_rgb(self, cat_feature, gt_score_map=None):
        """
        cat_feature: output embeddings of the backbone, it can be (HW1+HW2, B, C) or (HW2, B, C)
        """
        enc_opt = cat_feature[:, -self.feat_len_s:]  # encoder output for the search region (B, HW, C)
        opt = (enc_opt.unsqueeze(-1)).permute((0, 3, 2, 1)).contiguous()
        bs, Nq, C, HW = opt.size()
        opt_feat = opt.view(-1, C, self.feat_sz_s, self.feat_sz_s)

        if self.head_type == "CORNER":
            # run the corner head
            pred_box, score_map = self.box_head_rgb(opt_feat, True)
            outputs_coord = box_xyxy_to_cxcywh(pred_box)
            outputs_coord_new = outputs_coord.view(bs, Nq, 4)
            out = {'pred_boxes': outputs_coord_new,
                   'score_map': score_map,
                   }
            return out

        elif self.head_type == "CENTER":
            # run the center head
            score_map_ctr, bbox, size_map, offset_map = self.box_head_rgb(opt_feat, gt_score_map)
            # outputs_coord = box_xyxy_to_cxcywh(bbox)
            outputs_coord = bbox
            outputs_coord_new = outputs_coord.view(bs, Nq, 4)
            out = {'pred_boxes': outputs_coord_new,
                   'score_map': score_map_ctr,
                   'size_map': size_map,
                   'offset_map': offset_map}
            return out
        else:
            raise NotImplementedError
    def forward_head_t(self, cat_feature, gt_score_map=None):
        """
        cat_feature: output embeddings of the backbone, it can be (HW1+HW2, B, C) or (HW2, B, C)
        """
        enc_opt = cat_feature[:, -self.feat_len_s:]  # encoder output for the search region (B, HW, C)
        opt = (enc_opt.unsqueeze(-1)).permute((0, 3, 2, 1)).contiguous()
        bs, Nq, C, HW = opt.size()
        opt_feat = opt.view(-1, C, self.feat_sz_s, self.feat_sz_s)

        if self.head_type == "CORNER":
            # run the corner head
            pred_box, score_map = self.box_head_t(opt_feat, True)
            outputs_coord = box_xyxy_to_cxcywh(pred_box)
            outputs_coord_new = outputs_coord.view(bs, Nq, 4)
            out = {'pred_boxes': outputs_coord_new,
                   'score_map': score_map,
                   }
            return out

        elif self.head_type == "CENTER":
            # run the center head
            score_map_ctr, bbox, size_map, offset_map = self.box_head_t(opt_feat, gt_score_map)
            # outputs_coord = box_xyxy_to_cxcywh(bbox)
            outputs_coord = bbox
            outputs_coord_new = outputs_coord.view(bs, Nq, 4)
            out = {'pred_boxes': outputs_coord_new,
                   'score_map': score_map_ctr,
                   'size_map': size_map,
                   'offset_map': offset_map}
            return out
        else:
            raise NotImplementedError
def build_ostrack_twobranch(cfg, training=True):
    current_dir = os.path.dirname(os.path.abspath(__file__))  # This is your Project Root
    pretrained_path = os.path.join(current_dir, '../../../pretrained_models')
    if cfg.MODEL.PRETRAIN_FILE and ('OSTrack' not in cfg.MODEL.PRETRAIN_FILE) and training:
        pretrained = os.path.join(pretrained_path, cfg.MODEL.PRETRAIN_FILE)
    else:
        pretrained = cfg.MODEL.PRETRAIN_FILE

    if cfg.MODEL.BACKBONE.TYPE == 'vit_base_patch16_224':
        backbone = vit_base_patch16_224(pretrained, drop_path_rate=cfg.TRAIN.DROP_PATH_RATE)
        hidden_dim = backbone.embed_dim
        patch_start_index = 1

    elif cfg.MODEL.BACKBONE.TYPE == 'vit_base_patch16_224_ce':  # this is selected
        backbone = vit_base_patch16_224_ce(pretrained, drop_path_rate=cfg.TRAIN.DROP_PATH_RATE,
                                           ce_loc=cfg.MODEL.BACKBONE.CE_LOC,
                                           ce_keep_ratio=cfg.MODEL.BACKBONE.CE_KEEP_RATIO,
                                           )
        # for RGBT hidden_dim
        hidden_dim = backbone.embed_dim
        patch_start_index = 1

    elif cfg.MODEL.BACKBONE.TYPE == 'vit_large_patch16_224_ce':
        backbone = vit_large_patch16_224_ce(pretrained, drop_path_rate=cfg.TRAIN.DROP_PATH_RATE,
                                            ce_loc=cfg.MODEL.BACKBONE.CE_LOC,
                                            ce_keep_ratio=cfg.MODEL.BACKBONE.CE_KEEP_RATIO,
                                            )

        hidden_dim = backbone.embed_dim
        patch_start_index = 1

    else:
        raise NotImplementedError
    transformer_rgb = Trans_rgb(dim=768, num_heads=12, qkv_bias=True)
    transformer_rgbe = Trans_rgbe(dim=768, num_heads=12, qkv_bias=True)    
    backbone.finetune_track(cfg=cfg, patch_start_index=patch_start_index)
    transformer_fusion=Trans_fusion(dim=768, num_heads=12, qkv_bias=True)
    box_head = build_box_head(cfg, hidden_dim)
    box_head_rgb = build_box_head(cfg, hidden_dim)
    box_head_t = build_box_head(cfg, hidden_dim)    
    model = OSTrack_twobranch(
        backbone,
        transformer_rgb, 
        transformer_rgbe,
        transformer_fusion,
        box_head,
        box_head_rgb,
        box_head_t,
        aux_loss=False,
        head_type=cfg.MODEL.HEAD.TYPE,
    )


    if 'OSTrack' in cfg.MODEL.PRETRAIN_FILE and training:
        checkpoint = torch.load(cfg.MODEL.PRETRAIN_FILE, map_location="cpu")
        param_dict_rgbt = dict()
        # for k,v in checkpoint["net"].items():
            # if k in ['box_head.conv1_ctr.0.weight','box_head.conv1_offset.0.weight','box_head.conv1_size.0.weight']:
                # param_dict_rgbt[k] = torch.cat([v,v],1)
            # else:
                # param_dict_rgbt[k] = v
        for k,v in checkpoint["net"].items():
            print("k",k)
            param_dict_rgbt[k] = v
        #pdb.set_trace() 
        
        box_head_rgb_dict = box_head_rgb.state_dict()
        #box_head_t_dict = box_head_t.state_dict()    

        # for k, v in checkpoint.items():
            # print("k",k)
            # if k[len('box_head.'):] in box_head_rgb_dict:
                # k[len('box_head.'):]: v             
        box_head_dict = {k[len('box_head.'):]: v for k, v in checkpoint["net"].items() if k[len('box_head.'):] in box_head_rgb_dict}
        box_head_rgb.load_state_dict(box_head_dict)
        box_head_t.load_state_dict(box_head_dict) 
        
        missing_keys, unexpected_keys = model.load_state_dict(param_dict_rgbt, strict=False)
        print('Load pretrained model from: ' + cfg.MODEL.PRETRAIN_FILE)
        print('missing_keys, unexpected_keys',missing_keys, unexpected_keys)
    return model
