
import numpy as np
from lib.test.evaluation.data import Sequence, Sequence_RGBT, BaseDataset, SequenceList
from lib.test.utils.load_text import load_text
import os
class CRSOTDataset(BaseDataset):
    def __init__(self):
        super().__init__()
        self.base_path = self.env_settings.crsot_dir
        self.sequence_list = self._get_sequence_list()

    def get_sequence_list(self):
        return SequenceList([self._construct_sequence(s) for s in self.sequence_list])

    def _construct_sequence(self, sequence_info):
        sequence_path = sequence_info['path']
        anno_path = sequence_info['anno_path']
        #anno_path_t = sequence_info['anno_path_t']        
        ground_truth_rect = load_text(str(anno_path), delimiter=['', '\t', ','], dtype=np.float64)
        #ground_truth_rect_t = load_text(str(anno_path_t), delimiter=['', '\t', ','], dtype=np.float64)        
        img_list_v = sorted([p for p in os.listdir(os.path.join(sequence_path, 'rgb_imgs')) if os.path.splitext(p)[1] in ['.jpg','.png','.bmp']])
        frames_v = [os.path.join(sequence_path, 'rgb_imgs', img) for img in img_list_v]
        
        img_list_e = sorted([p for p in os.listdir(os.path.join(sequence_path, 'event_imgs')) if os.path.splitext(p)[1] in ['.jpg','.png','.bmp']])
        frames_e = [os.path.join(sequence_path, 'event_imgs', img) for img in img_list_e]
        # Convert gt
        if ground_truth_rect.shape[1] > 4:
            gt_x_all = ground_truth_rect[:, [0, 2, 4, 6]]
            gt_y_all = ground_truth_rect[:, [1, 3, 5, 7]]

            x1 = np.amin(gt_x_all, 1).reshape(-1,1)
            y1 = np.amin(gt_y_all, 1).reshape(-1,1)
            x2 = np.amax(gt_x_all, 1).reshape(-1,1)
            y2 = np.amax(gt_y_all, 1).reshape(-1,1)

            ground_truth_rect = np.concatenate((x1, y1, x2-x1, y2-y1), 1)

        # if ground_truth_rect_t.shape[1] > 4:
            # gt_x_all = ground_truth_rect_t[:, [0, 2, 4, 6]]
            # gt_y_all = ground_truth_rect_t[:, [1, 3, 5, 7]]

            # x1 = np.amin(gt_x_all, 1).reshape(-1,1)
            # y1 = np.amin(gt_y_all, 1).reshape(-1,1)
            # x2 = np.amax(gt_x_all, 1).reshape(-1,1)
            # y2 = np.amax(gt_y_all, 1).reshape(-1,1)

            # ground_truth_rect_t = np.concatenate((x1, y1, x2-x1, y2-y1), 1)
        ground_truth_rect_v=ground_truth_rect        
        #return Sequence(sequence_info['name'], frames_v,  'rgbe_rgb', ground_truth_rect_v)
        return Sequence_RGBT(sequence_info['name'], frames_v, frames_e, 'rgbe', ground_truth_rect_v)
    def __len__(self):
        return len(self.sequence_info_list)
        
    def _get_sequence_list(self):
        sequence_list= ['00133_done', '00194_done', 'zurich_city_10_b_00_done', '00077_channel_done', '00024_done', 'zurich_city_05_a_08_done', 'zurich_city_12_a_04_done', 'zurich_city_10_b_07_done', '00105_done', '00168_done', '33', '10-ll-ego', '00045_done', '134-ego-good', 'zurich_city_11_b_08_done', '00198_done', '00150_done', '4-nl-lvl2', 'zurich_city_11_c_03_done', '00177_done', '20210920a_00168_done', '20210920a_00142_done', 'zurich_city_14_a_01_done', '152', '00316', 'zurich_city_15_a_01_done', '00274_pingpang', 'zurich_city_10_a_01_done', '00364', '20210920a_00148_done', '00352', 'zurich_city_11_c_08_done', '21-nl-lvl3-static-ego', '20210920e_00192_done', '189', '4-sl', '20210920a_00160_done', '20210920a_00128', 'zurich_city_10_b_09_done', '20210920a_00164_done', '20210920a_00178_done', '00246_pingpang', 'zurich_city_02_b_01_done', 'zurich_city_10_b_11_done', 'zurich_city_09_d_02_done', '00123_done', '00056_done', '00278', 'interlaken_00_a_01_done', '00006_done', '215', 'zurich_city_09_a_02_done', '00028_done', '00230_pingpang', 'zurich_city_11_a_03_done', '00317', '42', '5-nl-lvl3', 'zurich_city_01_a_01_done', '19-nl-lvl1-static-ego', '113-ego-rain-good', 'zurich_city_06_a_02_done', '171-ego', '112-rain', '20210920a_00025', '00061_done', '00065_done', '00383', '145', '00286', 'zurich_city_11_b_03_done', 'zurich_city_05_b_02_done', '00332', '29', 'zurich_city_09_a_07_done', '00117_done', '213-good', '00073_done', '00324', 'zurich_city_10_a_08_done', '221', '20210920a_00137_done', '00128_done', '00250_pingpang', 'zurich_city_02_d_03_done', '22', 'zurich_city_14_c_02_done', 'zurich_city_05_a_04_done', '12-nl-lvl4-ego', '00299', '18-nl-lvl2-static-ego', '00236_pingpang', '25-ego', '00137_topDOWN_done', '00069_done', '00363', '00257_pingpang', '9-nl-lvl1-ego', '00109_done', '00020_done', '00369', '20210920a_00153_done', '208-good', '00037_done', '00079_channel_done', '00338', '207',  '20210920a_00140_Sea_done', '00277_person', '20210920a_00173_done', '20210920_0079_Traffic_done', '00154_done', '20210920_0030', '00158_done', '00162_done', 'zurich_city_05_b_07_done', '127-ego-good', '20210920a_00115', '00050_done', '136', '28-flash', '21-ll', '20210921_00212_done', '00305', '00190_done', '00254_pingpang', '00183_done', '00377', '15-nl', '2-nl-ego', '20210920_0073', '154-shake-good', '20210920_0017', 'zurich_city_03_a_01_done', '20210920a_00038', 'interlaken_00_g_01_done', '8-nl-flash', '227', '00012_done', '179', '00203_done', '00100_done', '20210920a_00083', '00269_pingpang', 'zurich_city_15_a_05_done', '20210921_00205_done', '00357', '8-sl', '20210920a_00069', '119-long', '114-ego', '00033_done', '22-nl-lvl4-static-ego', '00241_pingpang', '160', '7-sl', '3-nl-lvl1', '20210920e_00186_done', '00346', '00180_done', 'interlaken_01_a_01_done', 'thun_01_b_01_done', '103-shake-good', '00292', 'zurich_city_10_b_17_done', '00089_done', '00387', '00094_done', '198', '00187_done', '20210921_00199_done', '118', '11-nl-lvl3-ego', '00145_done', 'zurich_city_04_d_01_done', 'zurich_city_01_e_05_done', '00173_done', '00263_pingpang', '20210920e_0001_CAT', '00016_done', 'zurich_city_02_d_09_done', '24-nl-flash-static-ego', '20210920a_00079_Traffic_done', 'zurich_city_10_b_16_done', 'zurich_city_04_a_01_done', '162-ego-good', '5-sl', '00113_done', '20210920_0060', '106-ego-good', '6-sl', '00082_done', '7-nl-flash', '00310']

        sequence_info_list = []
        for i in range(len(sequence_list)):
            sequence_info = {}
            sequence_info["name"] = sequence_list[i] 
            sequence_info["path"] = self.base_path+sequence_info["name"]
            #sequence_info["startFrame"] = int('1')
            #print(end_frame[i])
            #sequence_info["endFrame"] = end_frame[i]
                
            #sequence_info["nz"] = int('6')
            #sequence_info["ext"] = 'jpg'
            sequence_info["anno_path"] = sequence_info["path"]+'/groundtruth.txt'
            #sequence_info["anno_path_t"] = sequence_info["path"]+'/infrared.txt'            
            #sequence_info["object_class"] = 'person'
            sequence_info_list.append(sequence_info)
        return sequence_info_list
    