import numpy as np
from lib.test.evaluation.data import Sequence, Sequence_RGBT, BaseDataset, SequenceList
from lib.test.utils.load_text import load_text
import os

class COESOTDataset(BaseDataset):
    def __init__(self):
        super().__init__()
        self.base_path = self.env_settings.coesot_dir
        self.sequence_list = self._get_sequence_list()

    def get_sequence_list(self):
        return SequenceList([self._construct_sequence(s) for s in self.sequence_list])

    def _construct_sequence(self, sequence_info):
        sequence_path = sequence_info['path']
        anno_path = sequence_info['anno_path']
        #anno_path_t = sequence_info['anno_path_t']        
        ground_truth_rect = load_text(str(anno_path), delimiter=['', '\t', ','], dtype=np.float64)
        #ground_truth_rect_t = load_text(str(anno_path_t), delimiter=['', '\t', ','], dtype=np.float64)        
        img_list_v = sorted([p for p in os.listdir(os.path.join(sequence_path,sequence_info['name']+ '_aps')) if os.path.splitext(p)[1] in ['.jpg','.png','.bmp']])
        frames_v = [os.path.join(sequence_path,sequence_info['name']+ '_aps', img) for img in img_list_v]
        #print("frames_v",img_list_v)
        img_list_e = sorted([p for p in os.listdir(os.path.join(sequence_path, sequence_info['name']+'_dvs')) if os.path.splitext(p)[1] in ['.jpg','.png','.bmp']])
        frames_e = [os.path.join(sequence_path, sequence_info['name']+'_dvs', img) for img in img_list_e]
        # Convert gt
        if ground_truth_rect.shape[1] > 4:
            gt_x_all = ground_truth_rect[:, [0, 2, 4, 6]]
            gt_y_all = ground_truth_rect[:, [1, 3, 5, 7]]

            x1 = np.amin(gt_x_all, 1).reshape(-1,1)
            y1 = np.amin(gt_y_all, 1).reshape(-1,1)
            x2 = np.amax(gt_x_all, 1).reshape(-1,1)
            y2 = np.amax(gt_y_all, 1).reshape(-1,1)

            ground_truth_rect = np.concatenate((x1, y1, x2-x1, y2-y1), 1)

        # if ground_truth_rect_t.shape[1] > 4:
            # gt_x_all = ground_truth_rect_t[:, [0, 2, 4, 6]]
            # gt_y_all = ground_truth_rect_t[:, [1, 3, 5, 7]]

            # x1 = np.amin(gt_x_all, 1).reshape(-1,1)
            # y1 = np.amin(gt_y_all, 1).reshape(-1,1)
            # x2 = np.amax(gt_x_all, 1).reshape(-1,1)
            # y2 = np.amax(gt_y_all, 1).reshape(-1,1)

            # ground_truth_rect_t = np.concatenate((x1, y1, x2-x1, y2-y1), 1)
        # n=0
        # for i in range(len(ground_truth_rect)):
            # if ground_truth_rect[i,2]==0 or ground_truth_rect[i,3]==0:
                # n=n+1
            # else:
                # break
            
        ground_truth_rect_v=ground_truth_rect             
        #ground_truth_rect_v=ground_truth_rect        
        #return Sequence(sequence_info['name'], frames_v,  'rgbe_rgb', ground_truth_rect_v)
        return Sequence_RGBT(sequence_info['name'], frames_v, frames_e, 'coesot', ground_truth_rect_v)
    def __len__(self):
        return len(self.sequence_info_list)
        
    def _get_sequence_list(self):
        sequence_list = os.listdir(self.base_path)
        sequence_info_list = []
        for i in range(len(sequence_list)): 
            sequence_info = {}
            sequence_info["name"] = sequence_list[i] 
            sequence_info["path"] = self.base_path+sequence_info["name"]
            #sequence_info["startFrame"] = int('1')
            #print(end_frame[i])
            #sequence_info["endFrame"] = end_frame[i]
                
            #sequence_info["nz"] = int('6')
            #sequence_info["ext"] = 'jpg'
            sequence_info["anno_path"] = sequence_info["path"]+'/groundtruth.txt'
            #sequence_info["anno_path_t"] = sequence_info["path"]+'/infrared.txt'            
            #sequence_info["object_class"] = 'person'
            sequence_info_list.append(sequence_info)
        return sequence_info_list
    