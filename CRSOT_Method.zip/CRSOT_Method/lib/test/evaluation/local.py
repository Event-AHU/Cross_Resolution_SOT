import socket
from lib.test.evaluation.environment import EnvSettings

def local_env_settings():
    settings = EnvSettings()
    hostname = socket.gethostname()
    

    settings.lmdb_path="/home/zhaojiacong/datasets/lmdb_dataset/"
    settings.crsot_dir='/data1/Datasets/Tracking/CRSOT/test_subset/'
    settings.coesot_dir='//data1/Datasets/Tracking/COESOT/testing_subset/'  
    settings.visevent_dir='/data1/Datasets/Tracking/visevent/'      
    settings.gtot_path = '/Datasets/GTOT/'
    settings.lasher_path = '/home/zhaojiacong/datasets/LasHeR/'
    settings.lashertestingSet_path = '/home/zhaojiacong/datasets/LasHeR/'
    settings.lasher_unaligned = "/home/zhaojiacong/datasets/LasHeR_Ualigned/"
    
    # settings.network_path = '/home/zhaojiacong/all_pretrained/tomp/author/'    # Where tracking networks are stored.  # 预训练权重的路径
    settings.network_path = '/home/zhaojiacong/all_pretrained/trained_by_me/'    # 预训练权重的路径
    settings.results_path = '//data1/Code/zhuyabin/CRSOT_Method/tracking_result/'
    # settings.result_plot_path = '/home/zhaojiacong/all_result/lasher_test/'
    # settings.result_plot_path = '/home/zhaojiacong/all_result/rgbt234/'
    
    settings.rgbt210_path = '/home/zhaojiacong/datasets/RGBT210/'
    settings.rgbt234_path = '/home/zhaojiacong/datasets/RGBT234/'
    settings.gtot_dir = '/home/ps/GTOT/'
    settings.segmentation_path = '/data/liulei/pytracking/pytracking/segmentation_results/'

    settings.save_dir="/home/zhaojiacong/all_pretrained/"
    settings.prj_dir = "."
    


    return settings

